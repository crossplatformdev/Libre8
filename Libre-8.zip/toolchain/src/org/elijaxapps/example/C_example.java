package org.elijaxapps.example;

import org.elijaxapps.old.CompilerV8;

public class C_example {
    public static void main(String[] args) throws Exception {
        String[] commands = {
            "C_example.c"
        };
        CompilerV8.run(commands);
    }
}