package org.elijaxapps.example;

import org.elijaxapps.old.CompilerV8;

public class BASICV8 {
    public static void main(String[] args) throws Exception {
        String[] commands = {
            "BASIC.c"
        };
        CompilerV8.run(commands);
    }
}